# NutriSystem stakeholder review package

Extract this archive first. Open `_bmad-output/planning-artifacts/ux-designs/ux-nutrisystem-2026-10-07/mockups/index.html` in your browser for the offline gallery. Keep all extracted folders together so the links and food image work.

Read `_bmad-output/planning-artifacts/ux-designs/ux-nutrisystem-2026-10-07/REVIEW.md` for review sequence and limitations. The canonical PRD is `_bmad-output/planning-artifacts/prds/prd-nutrisystem-2026-10-07/prd.md`.

Completed stakeholder-review editions; approval and implementation readiness remain pending. All sample content is illustrative. Mock actions do not run services. GTM is deferred.
